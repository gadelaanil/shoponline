import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bottomwear',
  templateUrl: './bottomwear.component.html',
  styleUrls: ['./bottomwear.component.css']
})
export class BottomwearComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
