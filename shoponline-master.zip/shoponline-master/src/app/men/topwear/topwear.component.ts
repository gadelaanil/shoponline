import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-topwear',
  templateUrl: './topwear.component.html',
  styleUrls: ['./topwear.component.css']
})
export class TopwearComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
