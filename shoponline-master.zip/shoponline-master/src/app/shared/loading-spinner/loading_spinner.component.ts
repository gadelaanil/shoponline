import { Component } from '@angular/core';

@Component({
    selector:'app-loading-spinner',
    templateUrl:'./loading_spinner.component.html',
    styleUrls:['loading_spinner.component.css'] 
})
export class LoadingSpinnerComponent {

}