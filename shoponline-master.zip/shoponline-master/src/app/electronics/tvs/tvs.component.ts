import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tvs',
  templateUrl: './tvs.component.html',
  styleUrls: ['./tvs.component.css']
})
export class TvsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
