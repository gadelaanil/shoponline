import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeappliences',
  templateUrl: './homeappliences.component.html',
  styleUrls: ['./homeappliences.component.css']
})
export class HomeappliencesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
